
export interface UserData {
  id: string;
  name: string;
  progress: string;
  color: string;
}
